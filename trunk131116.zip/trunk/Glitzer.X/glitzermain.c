/****************************************************************************//**
* \file structcmd.h
* \brief A Documented file.
* Details.
*
* *************** GLITZER using PIC16F628A   ***********************
* IDE:         MPLAB X 
* Compiler:    XC8 V1.37
* File:        Glitzermain.c
* Project:     2016 11 Nr. 001
* File:        glitzermain.c
* Created on:  1. November 2016, 20:26
* Author:      jm
*                                                                               
* This Software is free for private use. Any commercial use is prohibited.
* you free to redistribute it or modify the code way you wish.
* This software is for educational purpose only.
*
* The author will not be responsible for any loss or liability whatsoever.
* In any circumstances jm shall not be liable for any
* special, incidental or consequential damages, for any reason whatsoever.
* No guarantee or warranty whatsoever. 
********************************************************************************/
 // http://microchip.wikidot.com/tls2101:start
/*******************************************************************************
* Includes
********************************************************************************/
#include <xc.h>
#include <limits.h>
//#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys.h>
//#include <pic16f628a.h>
//#include <pic16f628a.inc>

/********************************************************************************
* Constants
********************************************************************************/

#define TRUE = 1
#define FALSE = 0
#define _XTAL_FREQ = 4000000

/********************************************************************************
* Global Variables uintxxx Types needs <stdint.h>
********************************************************************************/
const unsigned char ROM_random_values[]={0x58,0x51,0x9f,0x2e,0xe7,0x8a,0x0c,
                                         0xab,0x47,0x99,0xdd,0x3d,0xed,0x15,
                                         0x7d,0xb6,0x20,0x61};

unsigned int loops=0;
unsigned int i=0;
unsigned char EEPROM_address=0,d=0;

unsigned int count_ints;


/********************************************************************************
* Arrays
********************************************************************************/

unsigned char random_values[16]; // 16 Bytes 


/*******************************************************************************
* Arrays 2 Dimensiones
********************************************************************************/

//uint8_t stripe[30][3];

/********************************************************************************
* Structs
********************************************************************************/

//struct pixelcolor{
//  uint8_t gbyte;
//  uint8_t rbyte;
//  uint8_t bbyte;
//}Pixelcolors[30];

//struct temp_pixelcolor{
//  uint8_t gbyte;
//  uint8_t rbyte;
//  uint8_t bbyte;
//}temp_pixelcolors;

/*******************************************************************//**
* Struct for RGB:
* Array for 30Pixel = Sripebuffer
* Predefined Colors
//                                                                    */

 /* TODO write stripe rewrite with predefined colors and pointer to it  */


/*******************************************************************//**
* Functionprototypes
************************************************************************/

void Init(void);

void Low(void);
void High(void);
void Res(void);
void Warte(int);

void Init_Stripe(void);

void Write_PXColors2Pixel(void);
void Write_PXColors2pixel2(void);

//oid Moving_Bloc(struct pxcolor *bloc_ptr,struct pxcolor *rest_ptr,uint8_t );
//void Moving_BlocS2E(struct pxcolor *bloc_ptr,struct pxcolor *rest_ptr,uint8_t);
//void Moving_BlocE2S(struct pxcolor *bloc_ptr,struct pxcolor *rest_ptr,uint8_t);
void Moving_Bloc2(void);
 /* TODO Add Prototypes.  */

/*******************************************************************//**
* void Warte(void)
* in:  loops  - how many times to delay 10ms
* out:
*
* \brief dalays for loops times 10ms
*
************************************************************************/

void Warte(int loops)
{
  for (i=0;i<loops;i++)
   {
   _delay(982);
   }
}


/*******************************************************************//**
* void Write_Pixel(uint8_t gbyte,uint8_t rbyte,uint8_t bbyte)
* in:   uint8_t gbyte,uint8_t rbyte,uint8_t bbyte GRB Values for Stripe
* out:
*
* \brief  writes whole stripe in runs ( 0 to 30)
*
************************************************************************/



/*******************************************************************//**
* void write_stripe_new
* \brief  writes whole stripe with pointer to array)monocolor
*
************************************************************************/


/*******************************************************************//**
* void write_stripe_mono
* \brief  writes whole stripe with pointer to array)monocolor
*
************************************************************************/

/*******************************************************************//**
* void Write_Pixel(unsigned char,unsigned char,unsigned char)
*
* \brief writes exactly one Pixel with one Byte for G,R,B
*
************************************************************************/

//void Write_Pixel(uint8_t gbyte,uint8_t rbyte,uint8_t bbyte)
//{
//  Write_Byte(gbyte);
//  Write_Byte(rbyte);
//  Write_Byte(bbyte);
//}

/*******************************************************************//**
* void write_byte(unsigned char )
*
* \brief splits one Byte in bit to drive Hardware
* Important! MSB must sent as first
*                                                                                                                                                                                                               *
************************************************************************/

//void Write_Byte(uint8_t bytetosend)
//{
////  uint8_t i;
////  uint8_t mask = 128 ;
////
////  for (i=0 ; i<8 ; i++)
////    {
////    if (bytetosend & mask) High();
////    else Low();
////    mask = mask>>1;
//    }
//}// write_byte













/*******************************************************************//**
* void prepare_pixel(unsigned char j)
*
* \brief  copys Pixelvalues
*
************************************************************************/



/*******************************************************************//**
* void prepare_pixel(unsigned char j)
*
* \brief  copys Pixelvalues
*
************************************************************************/
// prepare_pixel



//void increase(unsigned char G,unsigned char R,unsigned char B)
/*{
  for (c=0;c<255;c=c+5)
    {
    for (a=0;a<stripelenght;a++)
      {
      colorvalue = c;
      gbyte=G;
      rbyte=R;
      bbyte=colorvalue;
      Write_Pixel(gbyte,rbyte,bbyte);
      }
    warte(1);
    }
}*/

/*******************************************************************//**
* void Init_PXColors(void)
* in:   struct pxcolor bloc   holds color for moving bloc
*       struct pxcolor rest   holds backgroundcolor
*       uint8_t blocpixel     number of pixel builds bloc
* out:  none
*
* \brief  copys predefined colors to stripe struct Pointer based
*
************************************************************************/



/*******************************************************************//**
* void moving_bloc(void)
* in:  struct pxcolor *bloc_ptr pointer points to bloccolor
*      struct pxcolor *rest_ptr pointer points to backgroundcolor
*      uint8_t blocpxls         pixel in bloc
*
* \brief  moves bloc of pixel left to right and viceversa
* 
************************************************************************/


/*******************************************************************//**
* void moving_blocS2E(void)
* in:  struct pxcolor *bloc_ptr pointer points to bloccolor
*      struct pxcolor *rest_ptr pointer points to backgroundcolor
*      uint8_t blocpxls         pixel in bloc
*
* \brief  moves bloc of pixel from Start to End of Stripe
*
************************************************************************/


/*******************************************************************//**
* void moving_blocE2S(void)
* in:  struct pxcolor *bloc_ptr pointer points to bloccolor
*      struct pxcolor *rest_ptr pointer points to backgroundcolor
*      uint8_t blocpxls         pixel in bloc
*
* \brief  moves bloc of pixel from End to Start of Stripe
*
************************************************************************/
/* TODO Loop testwise removed*/


/*******************************************************************//**
* void moving_bloc2(void)
*
* \brief  moves bloc of pixel left to right and viceversa
*
************************************************************************/



/*******************************************************************//**
* void fade(void)
*
* \brief  only for debugging
*
************************************************************************/
//void fade(void)
//{
// int loops,i,up, down;
//
//     PORTAbits.RA1 =0;
//     i=0,up=0,down=128;
//         for (loops = 0;loops < 255;loops++)
//         {  
//           if (loops <128)                         // increase Brightness
//           {                       
//             PORTBbits.RB5 = 1;                // Einschalten
//             up++;
//             for (i = 0;i < 128;i++)
//             if (i>=up) PORTBbits.RB5 = 0;     // Ausschalten
//           }
//           if (loops>128)                         // decrease Brightness
//           {
//             PORTBbits.RB5 = 1;                // Einschalten    
//             down--;   
//             for (i = 0;i < 128;i++)
//             if (i>=down) PORTBbits.RB5 = 0;   // Ausschalten
//           }  
//         }     
//}
/*******************************************************************//**
* void uart_send(char ch)
*
* \brief  only for debugging
*
************************************************************************/

//// interner Zustand
//static unsigned int x = 123456789; // <- beliebige seed != 0
//static unsigned int y = 362436000;
//static unsigned int z = 521288629;
//static unsigned int c = 7654321;
//
//unsigned long int  KISS() {
//   unsigned long int t;
//
//   // Linearer Kongruenzgenerator
//   x = 69069 * x + 12345;
//
//   // Xorshift
//   y ^= y << 13;
//   y ^= y >> 17;
//   y ^= y << 5;
//
//   // Multiply-with-carry
//   t = 698769069UL * z + c;
//   c = t >> 32;
//   z = (unsigned int) t;
//
//   return x + y + z;
//}

/*******************************************************************//**
* void Init()
*
* \brief  Init all needed Hardware
*
************************************************************************/
void Init(void)
{
    int ii=0;
    PORTA = 0;   // clear PORT A 
    TRISA = 0;   // PORT A all Output
    
    PORTB = 0;   // clear PORT B 
    TRISB = 0;   // PORT B all Output
    
// EEPROM read    
     
     for (ii = 0;ii < 15;ii++)
      {
         random_values[ii] = ROM_random_values[ii];
      }

}

/*******************************************************************//**
* void InitInterupt()
*
* \brief  Init Interuptrelated things
*
************************************************************************/
void InitInterrupt(void)
{
// Timerinterupt T0 4 MHz int clock ==> 1ms Interrupt 
    
    OPTION_REGbits.T0CS   = 0;         // Timer increments on instruction clock
    OPTION_REGbits.PSA    = 0;         // Prescaler works for Timer 0
    OPTION_REGbits.PS2    = 0;// Prescaler
    OPTION_REGbits.PS1    = 0;
    INTCONbits.T0IE       = 1;         // Enable interrupt on TMR0 overflow
    OPTION_REGbits.INTEDG = 0;         // falling edge trigger the interrupt
    INTCONbits. GIE       = 1;         // Global interrupt enable
}        
        


void interrupt   tc_int  (void)        // interrupt function 
 
{
    if(INTCONbits.T0IF && INTCONbits.T0IE) 
    {                              // if timer flag is set & interrupt enabled
      //  TMR0 -= 250;               // reload the timer - 250uS per interrupt
      count_ints++;
      
     if (count_ints == 50) 
     { 
         PORTAbits.RA3 =0;  // toggle a bit to say we're alive
         PORTBbits.RB3 =1;
     }
     if (count_ints == 16383) 
     {    
         PORTAbits.RA3 =1;
         PORTBbits.RB3 =0;
     }
     if (count_ints >= 32767)  
     {
         count_ints = 0; 
     }    
     INTCONbits.T0IF = 0;       // clear the interrupt flag     
    }
}
/*******************************************************************//**
* void main(void)
*
* \brief  the main code
*
************************************************************************/

 /* TODO cleanup  */
 main()
{
     Init();
     InitInterrupt();
     while(1)
     { int loops,i,up, down;
//1
     PORTAbits.RA1 =0;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB5 = 1;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB5 = 0;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB5 = 1;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB5 = 0;   // Ausschalten
           }  
         }   
        
     PORTAbits.RA1 =1;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB5 = 0;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB5 = 1;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB5 = 0;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB5 = 1;   // Ausschalten
           }  
         }   
     PORTAbits.RA1 =1;
     PORTBbits.RB5 = 0;   
 //2    
     PORTAbits.RA7 =0;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB4 = 1;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB4 = 0;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB4 = 1;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB4 = 0;   // Ausschalten
           }  
         }     
     PORTAbits.RA7 =1;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB4 = 0;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB4 = 1;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB4 = 0;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB4 = 1;   // Ausschalten
           }  
         }
     PORTAbits.RA7 =0;
     PORTBbits.RB4 = 0;
  //3    
     PORTAbits.RA0 =0;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB7 = 1;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB7 = 0;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB7 = 1;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB7 = 0;   // Ausschalten
           }  
         }     
     PORTAbits.RA0 =1;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB7 = 0;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB7 = 1;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB7 = 0;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB7 = 1;   // Ausschalten
           }  
         }
     PORTAbits.RA0 =0;
     PORTBbits.RB7 = 0;   
 //4    
     PORTAbits.RA6 =0;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB6 = 1;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB6 = 0;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB6 = 1;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB6 = 0;   // Ausschalten
           }  
         }     
     PORTAbits.RA6 =1;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB6 = 0;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB6 = 1;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB6 = 0;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB6 = 1;   // Ausschalten
           }  
         }
     PORTAbits.RA6 =0;
     PORTBbits.RB6 = 0;
     
   //5 ra2 rb1   
     PORTAbits.RA2 =0;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB1 = 1;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB1 = 0;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB1 = 1;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB1 = 0;   // Ausschalten
           }  
         }     
     PORTAbits.RA2 =1;
     i=0,up=0,down=128;
         for (loops = 0;loops < 255;loops++)
         {  
           if (loops <128)                         // increase Brightness
           {                       
             PORTBbits.RB1 = 0;                // Einschalten
             up++;
             for (i = 0;i < 128;i++)
             if (i>=up) PORTBbits.RB1 = 1;     // Ausschalten
           }
           if (loops>128)                         // decrease Brightness
           {
             PORTBbits.RB1 = 0;                // Einschalten    
             down--;   
             for (i = 0;i < 128;i++)
             if (i>=down) PORTBbits.RB1 = 1;   // Ausschalten
           }  
         }
     PORTAbits.RA2 =0;
     PORTBbits.RB1 = 0;  
     
     }         
 }
//main

// no code behind this line



     
 
